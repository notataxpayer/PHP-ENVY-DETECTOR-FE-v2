import { useState } from "react";
import HeroSection from "../sections/HeroSection";
import UploadSection from "../sections/UploadSection";
import SelectedFilesSection from "../sections/SelectedFilesSection";
import AnalyzeSection from "../sections/AnalyzeSection";
import InfoSection from "../sections/InfoSection";

// View component page untuk upload dan analisis file
export default function UploadPage({ setResult }) {
  const [files, setFiles] = useState([]);

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="max-w-6xl mx-auto px-6 py-10 space-y-8">

        <HeroSection />

        <UploadSection
          files={files}
          setFiles={setFiles}
        />

        <SelectedFilesSection files={files} />

        <InfoSection />

        <AnalyzeSection
          files={files}
          setResult={setResult}
          setFiles={setFiles}
        />

      </div>
    </div>
  );
}
