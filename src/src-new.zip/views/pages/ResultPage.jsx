import ResultSummary from "../result/ResultSummary";
import FileResultCard from "../result/FileResultCard";
import DownloadPDFButton from "../result/DownloadPDFButton";
import PDFReport from "../result/PDFReport";

// View component page untuk menampilkan hasil analisis
export default function ResultPage({
  data,
  onReset,
}) {
  // Fungsi untuk menangani klik tombol reset dan kembali ke halaman upload
  const handleReset = () => {
    onReset();
  };

  if (!data) return null;

  return (
    <div className="space-y-6">

      {/* ACTION BUTTONS */}
      <div className="flex justify-end gap-4">

        {/* RESET BUTTON */}
        <button
          onClick={handleReset}
          className="bg-red-500 hover:bg-red-600 text-white px-6 py-3 rounded-2xl shadow transition"
        >
          Reset
        </button>

        {/* DOWNLOAD PDF BUTTON */}
        <DownloadPDFButton />

      </div>

      {/* ANALYSIS SUMMARY */}
      <ResultSummary data={data} />

      {/* DETAILED RESULTS PER FILE */}
      {data.map((file, index) => (
        <FileResultCard
          key={index}
          file={file}
        />
      ))}

      {/* PDF VERSION (HIDDEN - FOR DOWNLOAD ONLY) */}
      <div className="hidden">
        <PDFReport data={data} />
      </div>

    </div>
  );
}
