import html2pdf from "html2pdf.js";

// View component untuk tombol download PDF report hasil analisis
export default function DownloadPDFButton() {

  // Fungsi untuk mendownload PDF report dari element HTML yang sudah dibuat
  const downloadPDF = async () => {
    const element = document.getElementById("pdf-report");

    const options = {
      margin: 0.5,
      filename: "feature-envy-report.pdf",
      image: {
        type: "jpeg",
        quality: 1,
      },
      html2canvas: {
        scale: 2,
      },
      jsPDF: {
        unit: "in",
        format: "a4",
        orientation: "portrait",
      },
    };

    await html2pdf()
      .set(options)
      .from(element)
      .save();
  };

  return (
    <button
      onClick={downloadPDF}
      className="bg-black text-white px-6 py-3 rounded-2xl"
    >
      Download PDF
    </button>
  );
}
