import { useState } from "react";

import UploadPage from "./views/pages/UploadPage";
import ResultPage from "./views/pages/ResultPage";

// Main App component - Fungsi untuk mengelola state global dan routing utama aplikasi
function App() {

  const [result, setResult] = useState(null);

  // Fungsi untuk reset hasil analisis dan kembali ke halaman upload
  const handleReset = () => {
    setResult(null);
  };

  return (
    <div className="min-h-screen bg-gray-100 p-6">

      {!result && (
        <UploadPage setResult={setResult} />
      )}

      {result && (
        <ResultPage
          data={result}
          onReset={handleReset}
        />
      )}

    </div>
  );
}

export default App;