import { addFiles, removeFile, getFileCount, getTotalFileSize, isValidPhpFile, clearAllFiles } from '../models/fileModel';

// Controller untuk menangani logika upload dan manajemen file
export const useFileController = () => {
  // Fungsi untuk menambahkan file baru yang dipilih ke dalam array
  const addFilesController = (currentFiles, newFiles) => {
    return addFiles(currentFiles, newFiles);
  };

  // Fungsi untuk menghapus file dari array berdasarkan index
  const removeFileByIndex = (currentFiles, index) => {
    return removeFile(currentFiles, index);
  };

  // Fungsi untuk mendapatkan jumlah file yang dipilih
  const getFileCountController = (files) => {
    return getFileCount(files);
  };

  // Fungsi untuk menghitung total ukuran semua file
  const calculateTotalSize = (files) => {
    return getTotalFileSize(files);
  };

  // Fungsi untuk validasi bahwa file adalah file PHP yang valid
  const validatePhpFile = (file) => {
    return isValidPhpFile(file);
  };

  // Fungsi untuk reset/clear semua file yang dipilih
  const clearFiles = () => {
    return clearAllFiles();
  };

  return {
    addFilesController,
    removeFileByIndex,
    getFileCountController,
    calculateTotalSize,
    validatePhpFile,
    clearFiles,
  };
};
