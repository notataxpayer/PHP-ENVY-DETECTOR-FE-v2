import { analyzeFiles, mergeDetectionAndMetrics, calculateStatistics } from '../models/analysisModel';

// Controller untuk menangani logika upload dan analisis kode
export const useAnalyzeController = () => {
  // Fungsi untuk mengeksekusi analisis file dan menggabungkan hasil detection dengan metrics
  const handleAnalyzeFiles = async (files) => {
    try {
      const response = await analyzeFiles(files);
      const { detection, metrics } = response;

      const mergedData = mergeDetectionAndMetrics(detection, metrics);
      return mergedData;
    } catch (error) {
      console.error('Analysis failed:', error);
      throw error;
    }
  };

  // Fungsi untuk menghitung statistik dari hasil analisis
  const getAnalysisStatistics = (data) => {
    return calculateStatistics(data);
  };

  return {
    handleAnalyzeFiles,
    getAnalysisStatistics,
  };
};
